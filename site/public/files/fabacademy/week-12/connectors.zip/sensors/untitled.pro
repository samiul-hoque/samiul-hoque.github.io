EAGLE AutoRouter Statistics:

Job           : D:/Users/sami/Documents/EAGLE/projects/sensors/untitled.brd

Start at      : 13:50:00 (4/5/2019)
End at        : 13:50:58 (4/5/2019)
Elapsed time  : 00:00:39

Signals       :    19   RoutingGrid: 12.5 mil  Layers: 1
Connections   :    19   predefined:  3 ( 0 Vias )

Router memory :   337212

Passname          :    Busses     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:00:00  00:00:38  00:00:00  00:00:00  00:00:01  00:00:00
Number of Ripups  :         0       400         0         0         0         0
max. Level        :         0         2         0         0         0         0
max. Total        :         0         3         0         0         0         0

Routed            :        11        12        12        12        12        12
Vias              :         0         0         0         0         0         0
Resolution        :    73.7 %    78.9 %    78.9 %    78.9 %    78.9 %    78.9 %

Final             : 78.9% finished
