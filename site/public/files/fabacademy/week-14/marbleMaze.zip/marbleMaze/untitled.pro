EAGLE AutoRouter Statistics:

Job           : D:/Users/sami/Documents/EAGLE/projects/marbleMaze/untitled.brd

Start at      : 18:14:04 (4/25/2019)
End at        : 18:28:15 (4/25/2019)
Elapsed time  : 00:10:40

Signals       :    25   RoutingGrid: 6.25 mil  Layers: 1
Connections   :    71   predefined:  0 ( 0 Vias )

Router memory :   1296416

Passname          :     Route Optimize1 Optimize2 Optimize3 Optimize4

Time per pass     :  00:10:35  00:00:01  00:00:02  00:00:01  00:00:01
Number of Ripups  :      1117         0         0         0         0
max. Level        :         3         0         0         0         0
max. Total        :        40         0         0         0         0

Routed            :        62        62        62        62        62
Vias              :         0         0         0         0         0
Resolution        :    87.3 %    87.3 %    87.3 %    87.3 %    87.3 %

Final             : 87.3% finished
