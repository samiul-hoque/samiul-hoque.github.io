/*
 * at44_test.c
 *
 * Created: 4/13/2019 12:09:57 PM
 * Author : sami
 */ 
#define F_CPU 20000000UL 
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{	
	DDRA =0b00011000;       //Set PA3 and 4 as OUTPUT   
    while (1) 
    {
	
		PORTA = 0b00001000;
		PORTA = 0b00010000;
		_delay_ms(500);
		
		PORTA = 0b00010000;
		PORTA = 0b00001000;
		_delay_ms(500);
    }
	return 1;
}

