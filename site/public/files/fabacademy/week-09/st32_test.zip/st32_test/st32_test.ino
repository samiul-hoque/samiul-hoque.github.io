const int led = PC13;


void setup() {
  // put your setup code here, to run once:
pinMode(led, OUTPUT);
}

void loop() {
  digitalWrite(led, LOW);
  delay(1000);
  digitalWrite(led, HIGH);
  delay(500);
}
