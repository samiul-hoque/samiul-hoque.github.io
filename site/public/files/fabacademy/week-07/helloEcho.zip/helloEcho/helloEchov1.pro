EAGLE AutoRouter Statistics:

Job           : D:/Users/sami/Documents/EAGLE/projects/helloEcho/helloEchov1.brd

Start at      : 11:49:34 (3/3/2019)
End at        : 11:49:44 (3/3/2019)
Elapsed time  : 00:00:04

Signals       :    16   RoutingGrid: 16 mil  Layers: 1
Connections   :    35   predefined:  0 ( 0 Vias )

Router memory :   25228

Passname          : TopRouter     Route Optimize1 Optimize2 Optimize3 Optimize4 Optimize5 Optimize6 Optimize7 Optimize8 Optimize9Optimize10Optimize11Optimize12

Time per pass     :  00:00:01  00:00:02  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:01  00:00:00  00:00:00  00:00:00  00:00:00
Number of Ripups  :         0       108         0         0         0         0         0         0         0         0         0         0         0         0
max. Level        :         0         4         0         0         0         0         0         0         0         0         0         0         0         0
max. Total        :         0        17         0         0         0         0         0         0         0         0         0         0         0         0

Routed            :        17        34        33        33        33        33        33        33        33        33        33        33        33        33
Vias              :         0         0         0         0         0         0         0         0         0         0         0         0         0         0
Resolution        :    48.6 %    97.1 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %

Final             : 94.3% finished
