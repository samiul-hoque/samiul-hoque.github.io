EAGLE AutoRouter Statistics:

Job           : D:/Users/sami/Documents/EAGLE/projects/helloEcho/untitled.brd

Start at      : 18:38:01 (3/2/2019)
End at        : 18:38:15 (3/2/2019)
Elapsed time  : 00:00:09

Signals       :    16   RoutingGrid: 15.5 mil  Layers: 1
Connections   :    35   predefined:  0 ( 0 Vias )

Router memory :   31752

Passname          : TopRouter     Route Optimize1 Optimize2 Optimize3 Optimize4 Optimize5 Optimize6 Optimize7 Optimize8 Optimize9Optimize10Optimize11Optimize12

Time per pass     :  00:00:01  00:00:07  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:00  00:00:01  00:00:00
Number of Ripups  :         0       318         0         0         0         0         0         0         0         0         0         0         0         0
max. Level        :         0         4         0         0         0         0         0         0         0         0         0         0         0         0
max. Total        :         0        18         0         0         0         0         0         0         0         0         0         0         0         0

Routed            :        20        33        33        33        33        33        33        33        33        33        33        33        33        33
Vias              :         0         0         0         0         0         0         0         0         0         0         0         0         0         0
Resolution        :    57.1 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %    94.3 %

Final             : 94.3% finished
